import java.net.*;
import java.io.*;
import javax.swing.*;
public class Exercise3 {
	public static void main(String[] args) {
		String input = "";
		String server = "";
		try {
			Socket socket = new Socket("smtpdsl4.pldtdsl.net", 587);
			DataInputStream dis = new DataInputStream(socket.getInputStream());
			DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
			while (!input.equalsIgnoreCase("QUIT")){
				server = server + dis.readLine();
				input = JOptionPane.showInputDialog(server);
				dos.writeBytes(input+"\r\n");
				server = "S: " + server + "\n" + "C: " + input + "\n";
			}
			socket.close();
			System.exit(0);
		} catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
}